# Cacao framework
A library for dynamic simulation/ optimization.

### Installation
```
pip install cacao
```

### Get started
How to run a test case inside folder <test_case>

```
python manage.py run test_case
```

How to start a new project in folder <test_case2>

```
python manage.py startproject test_case2
```
